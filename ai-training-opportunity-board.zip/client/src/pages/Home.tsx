import { useMemo, useState, type CSSProperties, type ReactNode } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  BadgeCheck,
  BriefcaseBusiness,
  Check,
  ChevronRight,
  CircleDot,
  Clock3,
  ExternalLink,
  Layers3,
  Link2,
  Mail,
  Search,
  Sparkles,
} from "lucide-react";

type Referral = {
  name: string;
  description: string;
  category: "AI training" | "Expert work" | "Voice & data";
  signal: string;
  url: string;
  mark: string;
  accent: string;
};

const referrals: Referral[] = [
  {
    name: "Sovrano AI",
    description: "AI evaluation and training work for contributors who enjoy careful, structured feedback.",
    category: "AI training",
    signal: "Contributor network",
    url: "https://app.sovrano.ai/signup?utm_source=user&utm_medium=referral&utm_campaign=mainReferral&utm_content=v1&source=referral&referral_code=Q2F6TE86",
    mark: "S",
    accent: "lime",
  },
  {
    name: "Micro1",
    description: "Remote opportunities across software, data, and AI talent projects.",
    category: "AI training",
    signal: "Remote projects",
    url: "https://refer.micro1.ai/referral/jobs?referralCode=3fccd99c-ee34-4ad0-be84-2160c6be8f26&utm_source=referral&utm_medium=share&utm_campaign=job_referral",
    mark: "M",
    accent: "violet",
  },
  {
    name: "Mercor",
    description: "Expert-led work matching for research, evaluation, and specialist AI projects.",
    category: "Expert work",
    signal: "Expert marketplace",
    url: "https://t.mercor.com/UcMkl",
    mark: "M",
    accent: "coral",
  },
  {
    name: "Ambrose Groups",
    description: "Flexible opportunities to contribute your knowledge to better AI systems.",
    category: "Expert work",
    signal: "Apply to join",
    url: "https://www.ambrosegroups.app/auth?ref=76BF92D2",
    mark: "A",
    accent: "sky",
  },
  {
    name: "AfterQuery Experts",
    description: "Subject-matter experts help shape high-quality answers, research, and model outputs.",
    category: "Expert work",
    signal: "Expert application",
    url: "https://experts.afterquery.com/apply?ref=uyoAIpowbYYtBUnogptciYqDrup1",
    mark: "A",
    accent: "yellow",
  },
  {
    name: "Silencio Voice AI",
    description: "Voice and speech data projects for contributors with a clear, expressive voice.",
    category: "Voice & data",
    signal: "Voice projects",
    url: "https://ai.silencio.store?ref=ADZP3G",
    mark: "S",
    accent: "pink",
  },
  {
    name: "Trainplex",
    description: "A growing hub for annotation, evaluation, and AI training tasks.",
    category: "AI training",
    signal: "Training tasks",
    url: "https://trainplex.info/register?ref=EDVTYBC",
    mark: "T",
    accent: "orange",
  },
  {
    name: "Ethos",
    description: "Join an expert network for testing and improving the next generation of AI agents.",
    category: "AI training",
    signal: "Agent evaluation",
    url: "https://agent.askethos.com/refer/zivl82w3npsb",
    mark: "E",
    accent: "mint",
  },
  {
    name: "Rex Zone",
    description: "A flexible portal for distributed contributor and data operations work.",
    category: "AI training",
    signal: "Contributor portal",
    url: "https://portal.rex.zone/login?inviteCode=NmE2MjQzZjUwY2M3YzEwODcyOTk3OTVi",
    mark: "R",
    accent: "blue",
  },
  {
    name: "Atlas Capture",
    description: "Real-world data capture opportunities that help make AI more useful in context.",
    category: "Voice & data",
    signal: "Data collection",
    url: "https://audit.atlascapture.io/?ref_id=6a8bb2b7482b1393573fdecb",
    mark: "A",
    accent: "lavender",
  },
];

const categoryFilters = ["All", "AI training", "Expert work", "Voice & data"] as const;
type Filter = (typeof categoryFilters)[number];

type Opportunity = {
  company: string;
  role: string;
  location: string;
  type: string;
  summary: string;
  tags: string[];
  compensation: string;
  details: string[];
  email?: string;
  phone?: string;
  accent: string;
};

const recentOpportunities: Opportunity[] = [
  {
    company: "LAT Aerospace",
    role: "Data Annotation Intern",
    location: "Gurugram · On-site",
    type: "3-month internship",
    summary: "Work with perception ML models and real aerospace data across annotation, testing, fine-tuning, and field deployment.",
    tags: ["Computer vision", "Aerospace data", "Immediate joining"],
    compensation: "Internship",
    details: ["Annotate and label video data", "Support model training and fine-tuning", "Test and evaluate perception models", "Participate in field deployment activities"],
    email: "hiring@lat.com",
    accent: "coral",
  },
  {
    company: "AnnotiqX AI Private Ltd",
    role: "2D & 3D Data Annotation",
    location: "India · Full-time",
    type: "100 positions available",
    summary: "Entry-level annotation work across image, video, LiDAR, and point-cloud datasets with training and guidelines provided.",
    tags: ["Freshers welcome", "LiDAR", "Point clouds"],
    compensation: "₹9,000 / month",
    details: ["Image and video annotation", "2D and 3D dataset work", "Training and guidelines provided", "Productivity-based incentives"],
    email: "arpana@annotiqx.co.in",
    phone: "7748805664",
    accent: "violet",
  },
];

function AccentMark({ letter, accent }: { letter: string; accent: string }) {
  return (
    <div className={`brand-mark brand-${accent}`} aria-hidden="true">
      {letter}
    </div>
  );
}

function AppLink({ href, children, className = "", ...props }: { href: string; children: ReactNode; className?: string; "aria-label"?: string }) {
  return (
    <a className={className} href={href} target="_blank" rel="noreferrer" {...props}>
      {children}
    </a>
  );
}

export default function Home() {
  const [filter, setFilter] = useState<Filter>("All");
  const [query, setQuery] = useState("");

  const filteredReferrals = useMemo(() => {
    const normalizedQuery = query.toLowerCase().trim();
    return referrals.filter((referral) => {
      const matchesFilter = filter === "All" || referral.category === filter;
      const matchesQuery =
        !normalizedQuery ||
        referral.name.toLowerCase().includes(normalizedQuery) ||
        referral.description.toLowerCase().includes(normalizedQuery) ||
        referral.category.toLowerCase().includes(normalizedQuery);
      return matchesFilter && matchesQuery;
    });
  }, [filter, query]);

  return (
    <div className="site-shell">
      <div className="noise" aria-hidden="true" />
      <header className="site-header">
        <a href="#top" className="wordmark" aria-label="AI Training Jobs home">
          <span className="wordmark-icon"><CircleDot size={14} strokeWidth={3} /></span>
          <span>AI TRAINING<span className="wordmark-dot">.</span></span>
        </a>
        <nav className="desktop-nav" aria-label="Primary navigation">
          <a href="#directory">Referrals</a>
          <a href="#opportunities">Recent drops</a>
          <a href="#how-it-works">How it works</a>
        </nav>
        <a href="#directory" className="header-cta">Explore roles <ArrowUpRight size={15} /></a>
      </header>

      <main id="top">
        <section className="hero-section content-width">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> REFERRAL INDEX / 01</div>
            <h1>Find your place in the <span>AI work</span> economy.</h1>
            <p className="hero-lede">
              A curated starting point for annotation, model evaluation, expert work, and other ways to help build better AI — with referral links in one place.
            </p>
            <div className="hero-actions">
              <a href="#directory" className="button button-primary">Browse referrals <ArrowDownRight size={17} /></a>
              <a href="#opportunities" className="text-link">See what&apos;s coming <ChevronRight size={16} /></a>
            </div>
            <div className="hero-footnote"><Check size={14} /> Links are shared for easy access; always check each platform&apos;s current terms.</div>
          </div>

          <div className="hero-visual" aria-label="Opportunity board preview">
            <div className="orb orb-one" aria-hidden="true" />
            <div className="orb orb-two" aria-hidden="true" />
            <div className="board-card board-back board-back-one" aria-hidden="true"><span>OPEN CALL</span><b>Data + AI</b></div>
            <div className="board-card board-back board-back-two" aria-hidden="true"><span>NEW SIGNAL</span><b>Expert work</b></div>
            <div className="board-card board-main">
              <div className="board-topline"><span className="live-dot" /> LIVE DIRECTORY <span className="board-index">01 / 10</span></div>
              <div className="board-title-row"><span className="board-symbol"><Sparkles size={19} /></span><div><p>CURATED FOR HUMANS</p><h2>Opportunities<br /><em>worth your time.</em></h2></div></div>
              <div className="board-rule" />
              <div className="board-feature"><div className="board-feature-label">FEATURED ROLE</div><div className="board-feature-name">LLM Trainer <span>— Agent function call</span></div><div className="board-feature-meta"><span><BriefcaseBusiness size={13} /> Turing</span><strong>$150 reward</strong></div></div>
              <a className="board-link" href="https://work.turing.com/r/y2DgoDEu7y" target="_blank" rel="noreferrer">View featured role <ArrowUpRight size={14} /></a>
            </div>
            <div className="visual-caption"><span>01</span><span>PEOPLE POWERING THE<br />MACHINE</span></div>
          </div>
        </section>

        <section className="signal-strip" aria-label="Directory highlights">
          <div className="content-width signal-grid">
            <div className="signal-item"><strong>10</strong><span>referral platforms<br />in the index</span></div>
            <div className="signal-item"><strong>03</strong><span>work types to<br />explore</span></div>
            <div className="signal-item"><strong>01</strong><span>featured opportunity<br />to start with</span></div>
            <div className="signal-note"><span className="signal-note-dot" /> Updated as new leads are found</div>
          </div>
        </section>

        <section id="directory" className="directory-section content-width">
          <div className="section-heading">
            <div><div className="eyebrow"><span className="eyebrow-line" /> THE DIRECTORY / 02</div><h2>Start with a <span>signal.</span></h2></div>
            <p>Explore trusted starting points across the AI training ecosystem. Each card takes you directly to the referral application.</p>
          </div>

          <div className="directory-toolbar">
            <div className="filter-tabs" role="tablist" aria-label="Filter referral platforms">
              {categoryFilters.map((category) => (
                <button key={category} className={filter === category ? "filter-tab active" : "filter-tab"} onClick={() => setFilter(category)} role="tab" aria-selected={filter === category}>{category}</button>
              ))}
            </div>
            <label className="search-field"><Search size={15} /><span className="sr-only">Search platforms</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search the index" /></label>
          </div>

          <div className="referral-grid">
            {filteredReferrals.map((referral, index) => (
              <article className="referral-card" key={referral.name} style={{ "--delay": `${Math.min(index * 45, 360)}ms` } as CSSProperties}>
                <div className="card-top"><AccentMark letter={referral.mark} accent={referral.accent} /><span className="card-number">{String(index + 1).padStart(2, "0")}</span></div>
                <div className="card-body"><div className="card-category">{referral.category}</div><h3>{referral.name}</h3><p>{referral.description}</p></div>
                <div className="card-footer"><span><span className="mini-dot" /> {referral.signal}</span><AppLink href={referral.url} className="card-arrow" aria-label={`Open ${referral.name} referral`}><ArrowUpRight size={17} /></AppLink></div>
              </article>
            ))}
          </div>
          {filteredReferrals.length === 0 && <div className="no-results"><Search size={18} /><p>No platforms match that search yet.</p><button onClick={() => { setQuery(""); setFilter("All"); }}>Clear filters</button></div>}
        </section>

        <section id="opportunities" className="opportunities-section">
          <div className="content-width">
            <div className="section-heading opportunities-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> FIELD NOTES / 03</div><h2>Recent <span>opportunities.</span></h2></div><p>Fresh roles and project drops will land here as they are found, checked, and ready to share.</p></div>
            <div className="opportunity-list">
              {recentOpportunities.map((opportunity, index) => (
                <article className="opportunity-card" key={opportunity.company}>
                  <div className={`opportunity-badge brand-${opportunity.accent}`}><span>{String(index + 1).padStart(2, "0")}</span><BriefcaseBusiness size={17} /></div>
                  <div className="opportunity-main">
                    <div className="opportunity-meta"><span>{opportunity.company}</span><span className="opportunity-live"><span className="status-pulse" /> OPEN LEAD</span></div>
                    <h3>{opportunity.role}</h3>
                    <p>{opportunity.summary}</p>
                    <div className="opportunity-tags">{opportunity.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
                  </div>
                  <div className="opportunity-side">
                    <div className="opportunity-facts"><span><CircleDot size={12} /> {opportunity.location}</span><span><Clock3 size={12} /> {opportunity.type}</span><strong>{opportunity.compensation}</strong></div>
                    <div className="opportunity-actions">
                      {opportunity.email && <a href={`mailto:${opportunity.email}?subject=Application%20for%20${encodeURIComponent(opportunity.role)}`} className="opportunity-apply">Email CV <Mail size={14} /></a>}
                      {opportunity.phone && <a href={`https://wa.me/91${opportunity.phone}`} target="_blank" rel="noreferrer" className="opportunity-whatsapp">WhatsApp <ArrowUpRight size={14} /></a>}
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="how-it-works" className="how-section content-width">
          <div className="how-intro"><div className="eyebrow"><span className="eyebrow-line" /> A SIMPLE LOOP / 04</div><h2>Less hunting.<br /><span>More making.</span></h2><p>The goal is simple: make the first step easier, then let your work speak for itself.</p></div>
          <div className="steps-grid">
            <div className="step-card"><div className="step-index">01</div><Layers3 size={23} /><h3>Browse</h3><p>Scan the directory for work types that fit your strengths, interests, and availability.</p></div>
            <div className="step-card step-highlight"><div className="step-index">02</div><Link2 size={23} /><h3>Follow the link</h3><p>Open the referral, complete the platform&apos;s own application, and read the current requirements.</p></div>
            <div className="step-card"><div className="step-index">03</div><BadgeCheck size={23} /><h3>Show up well</h3><p>Keep your profile clear, respond thoughtfully, and treat every task as a portfolio signal.</p></div>
          </div>
        </section>

        <section className="closing-section content-width">
          <div className="closing-card"><div><div className="eyebrow"><span className="eyebrow-line" /> KEEP IN TOUCH</div><h2>Want the next good lead?</h2><p>Recent opportunity posts and practical application notes are coming soon.</p></div><a className="button button-dark" href="mailto:hello@aitraining.jobs?subject=AI%20Training%20Jobs%20update">Get updates <Mail size={16} /></a></div>
        </section>
      </main>

      <footer className="site-footer content-width"><a href="#top" className="wordmark"><span className="wordmark-icon"><CircleDot size={14} strokeWidth={3} /></span><span>AI TRAINING<span className="wordmark-dot">.</span></span></a><span>Curated pathways into the work behind better AI.</span><a href="#top" className="back-top">Back to top <ArrowUpRight size={14} /></a></footer>
    </div>
  );
}
